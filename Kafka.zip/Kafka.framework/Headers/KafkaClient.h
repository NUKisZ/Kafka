//
//  Kafka.h
//  Kafka
//
//  Created by 张坤 on 2018/6/15.
//  Copyright © 2018年 张坤. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^SuccessBlock)(void);
typedef void (^FailerBlock)(NSError *error);

@interface KafkaClient : NSObject

+(instancetype) shareInstance;

- (void) kafka:(bool) auto_connect withClient_Id:(NSString *)client_id withSocket_timeout:(int) socket_timeout withBroker:(NSString *) brokerString;

/**
 添加Kafka探针监听


 @param message actionType 用户行为类型 data 操作参数 version 当前系统版本 clientType 用户终端类型
 @param topic 探针主题
 @param success 调用成功
 @param failer 调用失败
 */
- (void)sendMsg:(NSString *)message withTopic:(NSString *)topic success:(SuccessBlock)success failer:(FailerBlock)failer;



@end
